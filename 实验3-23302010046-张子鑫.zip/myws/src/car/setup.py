from setuptools import find_packages, setup

package_name = 'car'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='zzx',
    maintainer_email='zzx@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'car_sim = car.car_sim:main',
            'patrol_client = car.patrol_client:main',
            'switch_mode_client = car.switch_mode_client:main',
            'manual_controller_pub = car.manual_controller_pub:main',
        ],
    },
)
