# patrol_points_publisher.py
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import TransformStamped
from std_msgs.msg import String
from tf2_ros.static_transform_broadcaster import StaticTransformBroadcaster
from rclpy.qos import QoSProfile, DurabilityPolicy

class PatrolPointsPublisher(Node):
    def __init__(self):
        super().__init__('patrol_points_publisher')
        self.tf_broadcaster = StaticTransformBroadcaster(self)

        # 定义巡逻点（name, x, y）
        # 可以在这里改成想要的坐标序列
        self.points = [
            ('point_1', 7.0, 0.0),
            ('point_2', 1.5, 0.0),
            ('point_3', 5.5, 1.5),
            ('point_4', 0.0, 3.5),
        ]

        # 发布巡逻点名称列表（使用 transient_local 以便 late-join）
        qos = QoSProfile(depth=10)
        qos.durability = DurabilityPolicy.TRANSIENT_LOCAL
        self.list_pub = self.create_publisher(String, 'patrol_points', qos)

        # 发布静态变换（一次）
        self.publish_static_transforms()

        # 也发布一次名称列表（并可定期重发）
        self.publish_point_list()
        self.create_timer(5.0, self.publish_point_list)  # 每5s重发一次

        self.get_logger().info('PatrolPointsPublisher started, published static transforms and list.')

    def publish_static_transforms(self):
        tlist = []
        now = self.get_clock().now().to_msg()
        for name, x, y in self.points:
            t = TransformStamped()
            t.header.stamp = now
            t.header.frame_id = 'world'  # 根坐标系
            t.child_frame_id = name
            t.transform.translation.x = float(x)
            t.transform.translation.y = float(y)
            t.transform.translation.z = 0.0
            # 无旋转（四元数为 (0,0,0,1)）
            t.transform.rotation.x = 0.0
            t.transform.rotation.y = 0.0
            t.transform.rotation.z = 0.0
            t.transform.rotation.w = 1.0
            tlist.append(t)

        # static broadcaster：一次性发送整个列表
        self.tf_broadcaster.sendTransform(tlist)
        self.get_logger().info(f'Published {len(tlist)} static patrol point transforms.')

    def publish_point_list(self):
        names = [p[0] for p in self.points]
        msg = String()
        msg.data = ','.join(names)
        self.list_pub.publish(msg)
        self.get_logger().info(f'Published patrol point list: {msg.data}')

def main(args=None):
    rclpy.init(args=args)
    node = PatrolPointsPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()
