import rclpy
from rclpy.node import Node
from rclpy.action import ActionServer
from rclpy.callback_groups import ReentrantCallbackGroup
import threading
import time
import math


from std_msgs.msg import String
from geometry_msgs.msg import Point


from my_interfaces.action import Patrol
from my_interfaces.srv import SwitchMode

class CarSimNode(Node):


    def __init__(self):
        super().__init__("car_sim")


        self._cb_group = ReentrantCallbackGroup()

        # State
        self.position = Point()
        self.position.x = 0.0
        self.position.y = 0.0
        self.position.z = 0.0
        self.mode_keyboard = False # False: auto, True: manual
        self.total_distance = 0.0
        self.manual_cmd = 'stop'
        self._lock = threading.Lock()


        # Action server
        self._action_server = ActionServer(
        self,
        Patrol,
        'patrol_action',
        execute_callback=self.execute_callback,
        callback_group=self._cb_group,
        )


        # Service server
        self._srv = self.create_service(
        SwitchMode,
        'switch_mode',
        self.switch_mode_callback,
        callback_group=self._cb_group,
        )


        # Subscriber for manual commands
        self.create_subscription(
        String,
        'manual_cmd',
        self.manual_cmd_callback,
        10,
        callback_group=self._cb_group,
        )


        # Printer timer (1 Hz)
        self.create_timer(1.0, self._print_status, callback_group=self._cb_group)


        self.get_logger().info('CarSimNode started')
    def _print_status(self):
        with self._lock:
            self.get_logger().info(
            f"pos=({self.position.x:.2f},{self.position.y:.2f}) mode={'manual' if self.mode_keyboard else 'auto'} total_dist={self.total_distance:.2f}"
            )


    def manual_cmd_callback(self, msg: String):
        with self._lock:
            self.manual_cmd = msg.data.strip().lower()
            # For convenience accept synonyms
            if self.manual_cmd not in ('up', 'down', 'left', 'right', 'stop'):
                self.get_logger().info(f"unknown manual command '{msg.data}'")


    def switch_mode_callback(self, request, response):
        # request.keyboard_control (bool)
        with self._lock:
            # If request.keyboard_control True -> manual mode
            self.mode_keyboard = bool(request.keyboard_control)
            response.message = ('Switched to manual mode' if self.mode_keyboard else 'Switched to auto patrol mode')
            self.get_logger().info(response.message)
            return response
    def execute_callback(self, goal_handle):
        self.get_logger().info('Received patrol goal')
        points = goal_handle.request.points
        if not points:
            self.get_logger().info('No waypoints provided — finishing with failure')
            goal_handle.succeed()
            result = Patrol.Result()
            result.success = False
            return result
        with self._lock:
            self.mode_keyboard = False


        # Movement parameters
        speed = 0.5 # units per second
        dt = 0.1
        tolerance = 0.1


        for idx, target in enumerate(points):
            self.get_logger().info(f'Starting move to waypoint {idx}: ({target.x},{target.y})')


            reached = False
            while rclpy.ok() and not reached:
                with self._lock:
                    # If switched to manual, pause movement until back to auto
                    if self.mode_keyboard:
                    # pause: wait a bit then check again
                        pass
                    else:
                    # compute vector to target
                        dx = float(target.x) - float(self.position.x)
                        dy = float(target.y) - float(self.position.y)
                        dist = math.hypot(dx, dy)
                        if dist <= tolerance:
                            reached = True
                        else:
                        # move toward target
                            move_dist = min(speed * dt, dist)
                            nx = self.position.x + (dx / dist) * move_dist
                            ny = self.position.y + (dy / dist) * move_dist
                            # update total distance and position
                            self.total_distance += math.hypot(nx - self.position.x, ny - self.position.y)
                            self.position.x = nx
                            self.position.y = ny


                # If manual mode, obey manual commands (do not update towards target)
                with self._lock:
                    if self.mode_keyboard:
                    # manual movement per dt
                        mv = self._manual_move(speed, dt)
                        self.total_distance += math.hypot(mv[0], mv[1])
                        self.position.x += mv[0]
                        self.position.y += mv[1]


                # If reached just now, send feedback
                if reached:
                    feedback_msg = Patrol.Feedback()
                    feedback_msg.point_arrived = Point(x=target.x, y=target.y, z=0.0)
                    goal_handle.publish_feedback(feedback_msg)
                    self.get_logger().info(f'Reached waypoint {idx}: ({target.x},{target.y})')


            time.sleep(dt)


        # continue to next waypoints
        # All points visited
        goal_handle.succeed()
        result = Patrol.Result()
        result.success = True
        self.get_logger().info('Patrol finished successfully')
        return result
    def _manual_move(self, speed, dt):
        # Return tuple (dx, dy) to move this step based on self.manual_cmd
        cmd = self.manual_cmd
        step = speed * dt
        if cmd == 'up':
            return (0.0, step)
        elif cmd == 'down':
            return (0.0, -step)
        elif cmd == 'left':
            return (-step, 0.0)
        elif cmd == 'right':
            return (step, 0.0)
        else:
            return (0.0, 0.0)

def main(args=None):
    import rclpy
    rclpy.init(args=args)
    node = CarSimNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()

