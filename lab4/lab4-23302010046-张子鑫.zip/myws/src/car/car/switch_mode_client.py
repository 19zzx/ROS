import rclpy
from rclpy.node import Node
from my_interfaces.srv import SwitchMode  
import time
class SwitchModeClient(Node):
    def __init__(self):
        super().__init__('switch_mode_client')
        self.cli = self.create_client(SwitchMode, 'switch_mode')
        while not self.cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('waiting for switch_mode service...')


    def call_switch(self, keyboard_control: bool):
        req = SwitchMode.Request()
        req.keyboard_control = keyboard_control
        future = self.cli.call_async(req)
        rclpy.spin_until_future_complete(self, future)
        if future.result() is not None:
            self.get_logger().info(f'Service response: {future.result().message}')
        else:
            self.get_logger().info('Service call failed')

def main(args=None):
    import rclpy
    import time

    rclpy.init(args=args)
    node = SwitchModeClient()

    try:
        node.get_logger().info(
            "\n=== 模式切换客户端已启动 ===\n"
            "输入命令切换模式：\n"
            "  1 -> 切换到手动模式（Keyboard Control）\n"
            "  0 -> 切换到自动巡逻模式（Auto Patrol）\n"
            "  q -> 退出程序\n"
        )

        while rclpy.ok():
            cmd = input("请输入指令 (1/0/q)：").strip().lower()
            if cmd == 'q':
                node.get_logger().info("退出模式切换客户端。")
                break
            elif cmd == '1':
                node.call_switch(True)
            elif cmd == '0':
                node.call_switch(False)
            else:
                node.get_logger().info("无效输入，请输入 1 / 0 / q 。")

            time.sleep(0.2)

    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()
