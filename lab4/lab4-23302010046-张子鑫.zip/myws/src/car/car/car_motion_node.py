import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from tf2_ros import TransformBroadcaster
from geometry_msgs.msg import TransformStamped
from rclpy.time import Time


class CarMotionNode(Node):
    def __init__(self):
        super().__init__('car_motion_node')

        self.broadcaster = TransformBroadcaster(self)

        # subscribe velocity commands
        self.create_subscription(Twist, 'cmd_vel', self.cmd_cb, 10)

        # initial pose
        self.x = 0.0
        self.y = 0.0
        self.vx = 0.0
        self.vy = 0.0

        self.last_time = self.get_clock().now()

        self.create_timer(0.05, self.update)

        self.get_logger().info("CarMotionNode started (publishing dynamic transform world->car).")

    def cmd_cb(self, msg):
        self.vx = msg.linear.x
        self.vy = msg.linear.y

    def update(self):
        now = self.get_clock().now()
        dt = (now - self.last_time).nanoseconds / 1e9
        self.last_time = now

        # update pose
        self.x += self.vx * dt
        self.y += self.vy * dt

        # publish TF
        t = TransformStamped()
        t.header.stamp = now.to_msg()
        t.header.frame_id = 'world'
        t.child_frame_id = 'car'

        t.transform.translation.x = self.x
        t.transform.translation.y = self.y
        t.transform.translation.z = 0.0

        # no rotation needed
        t.transform.rotation.w = 1.0
        self.broadcaster.sendTransform(t)

        self.get_logger().info(f"car pose ({self.x:.2f}, {self.y:.2f})")

def main(args=None):
    rclpy.init(args=args)
    node = CarMotionNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()
