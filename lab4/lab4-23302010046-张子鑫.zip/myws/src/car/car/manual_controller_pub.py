import rclpy
from rclpy.node import Node         
from std_msgs.msg import String

class ManualController(Node):
    def __init__(self):
        super().__init__('manual_controller')
        self.pub = self.create_publisher(String, 'manual_cmd', 10)


    def publish_cmd(self, cmd: str):
        msg = String()
        msg.data = cmd
        self.pub.publish(msg)
        self.get_logger().info(f'Published manual cmd: {cmd}')

def main(args=None):
    import rclpy
    rclpy.init(args=args)
    node = ManualController()

    try:
        node.get_logger().info("Manual controller started. Enter direction: up/down/left/right/stop (or q to quit).")
        while rclpy.ok():
            cmd = input(">>> ").strip().lower()
            if cmd == 'q':
                break
            node.publish_cmd(cmd)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()
