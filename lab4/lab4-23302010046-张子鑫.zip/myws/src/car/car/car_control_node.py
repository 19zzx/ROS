import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import String
from tf2_ros import Buffer, TransformListener
from rclpy.time import Time


class CarControlNode(Node):
    def __init__(self):
        super().__init__('car_control_node')

        # TF buffer and listener
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        # publisher for velocity commands
        self.pub = self.create_publisher(Twist, 'cmd_vel', 10)

        # parameters
        self.rate_hz = 10.0
        self.timeout = 1.0
        self.arrival_tol = 0.1
        self.kp = 0.8
        self.max_speed = 1.0

        # patrol point list
        self.patrol_points = []
        self.current_idx = 0

        self.create_subscription(
            String,
            'patrol_points',
            self.patrol_points_cb,
            10
        )

        # control loop timer
        self.create_timer(1.0 / self.rate_hz, self.control_loop)

        self.get_logger().info("CarControlNode started. Waiting for patrol point list...")

    def patrol_points_cb(self, msg):
        names = [n.strip() for n in msg.data.split(',') if n.strip()]
        if names:
            if not self.patrol_points:
                # 第一次接收时初始化 current_idx
                self.patrol_points = names
                self.current_idx = 0
            else:
                # 之后仅更新列表，不重置 current_idx
                self.patrol_points = names

            self.get_logger().info(f'Received patrol points: {self.patrol_points}')


    def control_loop(self):
        if not self.patrol_points:
            return

        # current target
        target_frame = self.patrol_points[self.current_idx]

        try:
            now = Time()
            car_tf = self.tf_buffer.lookup_transform(
                'world', 'car', now, timeout=rclpy.duration.Duration(seconds=self.timeout)
            )
            point_tf = self.tf_buffer.lookup_transform(
                'world', target_frame, now, timeout=rclpy.duration.Duration(seconds=self.timeout)
            )
        except Exception as ex:
            self.get_logger().debug(f"TF lookup failed: {ex}")
            return

        car_x = car_tf.transform.translation.x
        car_y = car_tf.transform.translation.y
        pt_x = point_tf.transform.translation.x
        pt_y = point_tf.transform.translation.y

        dx = pt_x - car_x
        dy = pt_y - car_y
        dist = (dx*dx + dy*dy) ** 0.5

        if dist < self.arrival_tol:
            self.get_logger().info(f"Reached {target_frame}. Switching to next.")
            self.current_idx = (self.current_idx + 1) % len(self.patrol_points)
            self.pub.publish(Twist())  # stop
            return

        vx = self.kp * dx
        vy = self.kp * dy

        # clamp
        vx = max(-self.max_speed, min(self.max_speed, vx))
        vy = max(-self.max_speed, min(self.max_speed, vy))

        twist = Twist()
        twist.linear.x = float(vx)
        twist.linear.y = float(vy)
        
        self.get_logger().info(f"Moving towards {target_frame}: vx={vx:.2f}, vy={vy:.2f}, dist={dist:.2f}")
        self.pub.publish(twist)

    # ---- end of class ----


def main(args=None):
    rclpy.init(args=args)
    node = CarControlNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()
