import rclpy
from rclpy.node import Node     
from rclpy.action import ActionClient
from geometry_msgs.msg import Point
from my_interfaces.action import Patrol  
class PatrolClient(Node):
    def __init__(self):
        super().__init__('patrol_client')
        from rclpy.action import ActionClient
        self._action_client = ActionClient(self, Patrol, 'patrol_action')


    def send_patrol(self, points):
        self._action_client.wait_for_server()
        goal_msg = Patrol.Goal()
        goal_msg.points = points
        self._send_goal_future = self._action_client.send_goal_async(goal_msg, feedback_callback=self.feedback_cb)
        self._send_goal_future.add_done_callback(self._goal_response_cb)


    def _goal_response_cb(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().info('Goal rejected')
            return
        self.get_logger().info('Goal accepted')
        self._get_result_future = goal_handle.get_result_async()
        self._get_result_future.add_done_callback(self._get_result_cb)


    def _get_result_cb(self, future):
        result = future.result().result
        self.get_logger().info(f'Patrol result: success={result.success}')
        rclpy.shutdown()


    def feedback_cb(self, feedback_msg):
        pt = feedback_msg.feedback.point_arrived
        self.get_logger().info(f'Feedback: reached ({pt.x},{pt.y})')

def main(args=None):
    import rclpy
    from geometry_msgs.msg import Point
    rclpy.init(args=args)
    node = PatrolClient()
    # 示例路径
    points = [Point(x=1.0, y=0.0, z=0.0), Point(x=1.0, y=1.0, z=0.0)]
    node.send_patrol(points)
    rclpy.spin(node)