# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(my_interfaces_IDL_FILES "action/Patrol.idl;srv/SwitchMode.idl")
set(my_interfaces_INTERFACE_FILES "action/Patrol.action;srv/SwitchMode.srv;srv/SwitchMode_Request.msg;srv/SwitchMode_Response.msg")
