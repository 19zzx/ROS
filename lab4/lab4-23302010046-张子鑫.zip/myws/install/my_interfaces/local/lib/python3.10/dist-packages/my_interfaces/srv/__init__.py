from my_interfaces.srv._switch_mode import SwitchMode  # noqa: F401
