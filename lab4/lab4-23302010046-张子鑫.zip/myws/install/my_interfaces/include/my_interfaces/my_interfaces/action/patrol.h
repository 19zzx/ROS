// generated from rosidl_generator_c/resource/idl.h.em
// with input from my_interfaces:action/Patrol.idl
// generated code does not contain a copyright notice

#ifndef MY_INTERFACES__ACTION__PATROL_H_
#define MY_INTERFACES__ACTION__PATROL_H_

#include "my_interfaces/action/detail/patrol__struct.h"
#include "my_interfaces/action/detail/patrol__functions.h"
#include "my_interfaces/action/detail/patrol__type_support.h"

#endif  // MY_INTERFACES__ACTION__PATROL_H_
