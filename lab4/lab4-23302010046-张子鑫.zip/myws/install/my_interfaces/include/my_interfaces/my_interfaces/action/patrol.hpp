// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MY_INTERFACES__ACTION__PATROL_HPP_
#define MY_INTERFACES__ACTION__PATROL_HPP_

#include "my_interfaces/action/detail/patrol__struct.hpp"
#include "my_interfaces/action/detail/patrol__builder.hpp"
#include "my_interfaces/action/detail/patrol__traits.hpp"
#include "my_interfaces/action/detail/patrol__type_support.hpp"

#endif  // MY_INTERFACES__ACTION__PATROL_HPP_
