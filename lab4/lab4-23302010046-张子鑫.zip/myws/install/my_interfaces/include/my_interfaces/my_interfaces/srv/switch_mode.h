// generated from rosidl_generator_c/resource/idl.h.em
// with input from my_interfaces:srv/SwitchMode.idl
// generated code does not contain a copyright notice

#ifndef MY_INTERFACES__SRV__SWITCH_MODE_H_
#define MY_INTERFACES__SRV__SWITCH_MODE_H_

#include "my_interfaces/srv/detail/switch_mode__struct.h"
#include "my_interfaces/srv/detail/switch_mode__functions.h"
#include "my_interfaces/srv/detail/switch_mode__type_support.h"

#endif  // MY_INTERFACES__SRV__SWITCH_MODE_H_
