// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from my_interfaces:srv/SwitchMode.idl
// generated code does not contain a copyright notice

#ifndef MY_INTERFACES__SRV__DETAIL__SWITCH_MODE__BUILDER_HPP_
#define MY_INTERFACES__SRV__DETAIL__SWITCH_MODE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "my_interfaces/srv/detail/switch_mode__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace my_interfaces
{

namespace srv
{

namespace builder
{

class Init_SwitchMode_Request_keyboard_control
{
public:
  Init_SwitchMode_Request_keyboard_control()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::my_interfaces::srv::SwitchMode_Request keyboard_control(::my_interfaces::srv::SwitchMode_Request::_keyboard_control_type arg)
  {
    msg_.keyboard_control = std::move(arg);
    return std::move(msg_);
  }

private:
  ::my_interfaces::srv::SwitchMode_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::my_interfaces::srv::SwitchMode_Request>()
{
  return my_interfaces::srv::builder::Init_SwitchMode_Request_keyboard_control();
}

}  // namespace my_interfaces


namespace my_interfaces
{

namespace srv
{

namespace builder
{

class Init_SwitchMode_Response_message
{
public:
  Init_SwitchMode_Response_message()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::my_interfaces::srv::SwitchMode_Response message(::my_interfaces::srv::SwitchMode_Response::_message_type arg)
  {
    msg_.message = std::move(arg);
    return std::move(msg_);
  }

private:
  ::my_interfaces::srv::SwitchMode_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::my_interfaces::srv::SwitchMode_Response>()
{
  return my_interfaces::srv::builder::Init_SwitchMode_Response_message();
}

}  // namespace my_interfaces

#endif  // MY_INTERFACES__SRV__DETAIL__SWITCH_MODE__BUILDER_HPP_
