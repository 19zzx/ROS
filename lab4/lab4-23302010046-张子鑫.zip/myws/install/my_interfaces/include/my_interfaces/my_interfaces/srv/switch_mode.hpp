// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MY_INTERFACES__SRV__SWITCH_MODE_HPP_
#define MY_INTERFACES__SRV__SWITCH_MODE_HPP_

#include "my_interfaces/srv/detail/switch_mode__struct.hpp"
#include "my_interfaces/srv/detail/switch_mode__builder.hpp"
#include "my_interfaces/srv/detail/switch_mode__traits.hpp"
#include "my_interfaces/srv/detail/switch_mode__type_support.hpp"

#endif  // MY_INTERFACES__SRV__SWITCH_MODE_HPP_
