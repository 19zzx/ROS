from setuptools import setup
import os
from glob import glob

package_name = 'patrol_waypoint'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.py')),
        (os.path.join('share', package_name, 'config'), glob('config/*.yaml')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='zzx',
    maintainer_email='zzx@todo.todo',
    description='Waypoint patrol with Nav2',
    license='TODO',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'patrol_node = patrol_waypoint.patrol_node:main',
        ],
    },
)
