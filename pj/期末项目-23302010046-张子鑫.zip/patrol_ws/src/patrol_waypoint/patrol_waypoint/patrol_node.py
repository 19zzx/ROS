#!/usr/bin/env python3
import math
import yaml
from pathlib import Path

import rclpy
from rclpy.node import Node
from rclpy.duration import Duration

from geometry_msgs.msg import PoseStamped
from visualization_msgs.msg import Marker, MarkerArray
from nav2_simple_commander.robot_navigator import BasicNavigator, TaskResult


def yaw_to_quat(yaw: float):
    """Return (x,y,z,w) quaternion for yaw only (roll=pitch=0)."""
    return (0.0, 0.0, math.sin(yaw / 2.0), math.cos(yaw / 2.0))


class PatrolNode(Node):
    def __init__(self):
        super().__init__("patrol_node")

        self.declare_parameter("waypoints_yaml", "")
        self.declare_parameter("frame_id", "map")
        self.declare_parameter("loop", True)
        self.declare_parameter("dwell_time", 1.0)
        self.declare_parameter("goal_timeout_sec", 120.0)
        self.declare_parameter("retry_per_goal", 1)

        wp_path = self.get_parameter("waypoints_yaml").get_parameter_value().string_value
        if not wp_path:
            raise RuntimeError("Parameter waypoints_yaml is empty. Provide a YAML file path.")

        self.frame_id = self.get_parameter("frame_id").value
        self.loop = bool(self.get_parameter("loop").value)
        self.dwell_time = float(self.get_parameter("dwell_time").value)
        self.goal_timeout = float(self.get_parameter("goal_timeout_sec").value)
        self.retry_per_goal = int(self.get_parameter("retry_per_goal").value)

        self.navigator = BasicNavigator()

        self.marker_pub = self.create_publisher(MarkerArray, "patrol_waypoints", 1)

        self.waypoints = self.load_waypoints(wp_path)
        self.publish_waypoint_markers(self.waypoints)

        self.get_logger().info(f"Loaded {len(self.waypoints)} waypoints from {wp_path}")

        # Run patrol in a timer to avoid blocking constructor
        self.create_timer(1.0, self.start_once)
        self.started = False

    def start_once(self):
        if self.started:
            return
        self.started = True

        # Wait for Nav2 to be active (AMCL + BT navigator)
        self.get_logger().info("Waiting for Nav2 to become active...")
        self.navigator.waitUntilNav2Active()
        self.get_logger().info("Nav2 is active. Starting patrol.")

        self.run_patrol()

    def load_waypoints(self, wp_path: str):
        p = Path(wp_path).expanduser()
        data = yaml.safe_load(p.read_text(encoding="utf-8"))
        wps = data.get("waypoints", [])
        if not wps:
            raise RuntimeError("No waypoints found in YAML (expected key: waypoints).")
        return wps

    def make_pose(self, x: float, y: float, yaw: float):
        pose = PoseStamped()
        pose.header.frame_id = self.frame_id
        pose.header.stamp = self.get_clock().now().to_msg()
        pose.pose.position.x = float(x)
        pose.pose.position.y = float(y)
        qx, qy, qz, qw = yaw_to_quat(float(yaw))
        pose.pose.orientation.x = qx
        pose.pose.orientation.y = qy
        pose.pose.orientation.z = qz
        pose.pose.orientation.w = qw
        return pose

    def publish_waypoint_markers(self, wps):
        ma = MarkerArray()
        now = self.get_clock().now().to_msg()

        for i, wp in enumerate(wps):
            m = Marker()
            m.header.frame_id = self.frame_id
            m.header.stamp = now
            m.ns = "patrol_waypoints"
            m.id = i
            m.type = Marker.SPHERE
            m.action = Marker.ADD
            m.pose.position.x = float(wp["x"])
            m.pose.position.y = float(wp["y"])
            m.pose.position.z = 0.2
            m.pose.orientation.w = 1.0
            m.scale.x = 0.25
            m.scale.y = 0.25
            m.scale.z = 0.25
            m.color.a = 1.0
            m.color.r = 1.0
            m.color.g = 0.6
            m.color.b = 0.0
            ma.markers.append(m)

        self.marker_pub.publish(ma)

    def go_to_one(self, pose: PoseStamped):
        self.navigator.goToPose(pose)

        start = self.get_clock().now()
        timeout = Duration(seconds=self.goal_timeout)

        while rclpy.ok() and not self.navigator.isTaskComplete():
            feedback = self.navigator.getFeedback()
            if feedback:
                pass

            if self.get_clock().now() - start > timeout:
                self.get_logger().warn("Goal timeout. Canceling task...")
                self.navigator.cancelTask()
                return TaskResult.CANCELED

            rclpy.spin_once(self, timeout_sec=0.1)

        return self.navigator.getResult()

    def run_patrol(self):
        idx_cycle = 0
        while rclpy.ok():
            idx_cycle += 1
            self.get_logger().info(f"=== Patrol cycle {idx_cycle} ===")

            for i, wp in enumerate(self.waypoints):
                x, y, yaw = wp["x"], wp["y"], wp.get("yaw", 0.0)
                goal = self.make_pose(x, y, yaw)

                ok = False
                for attempt in range(self.retry_per_goal + 1):
                    self.get_logger().info(f"Going to waypoint {i}: x={x}, y={y}, yaw={yaw}, attempt={attempt+1}")
                    result = self.go_to_one(goal)

                    if result == TaskResult.SUCCEEDED:
                        self.get_logger().info(f"Waypoint {i} reached.")
                        ok = True
                        break
                    else:
                        self.get_logger().warn(f"Failed waypoint {i}, result={result}. Retrying...")

                if not ok:
                    self.get_logger().error(f"Give up waypoint {i}. Continue to next waypoint.")
                # dwell
                self.get_logger().info(f"Dwell {self.dwell_time}s")
                rclpy.spin_once(self, timeout_sec=self.dwell_time)

            if not self.loop:
                self.get_logger().info("Loop disabled. Patrol finished.")
                break


def main():
    rclpy.init()
    node = PatrolNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
