from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare

def generate_launch_description():
    # config/waypoints.yaml 的默认路径：通过包 share 找
    default_waypoints = PathJoinSubstitution([
        FindPackageShare('patrol_waypoint'),
        'config',
        'waypoints.yaml'
    ])

    waypoints_yaml = LaunchConfiguration('waypoints_yaml')

    return LaunchDescription([
        DeclareLaunchArgument(
            'waypoints_yaml',
            default_value=default_waypoints,
            description='Path to waypoint YAML file'
        ),

        Node(
            package='patrol_waypoint',
            executable='patrol_node',
            name='patrol_node',
            output='screen',
            parameters=[{
                'waypoints_yaml': waypoints_yaml,
                'frame_id': 'map',
                'loop': True,
                'dwell_time': 1.0,
                'goal_timeout_sec': 300.0,
                'retry_per_goal': 1,
            }],
        ),
    ])
