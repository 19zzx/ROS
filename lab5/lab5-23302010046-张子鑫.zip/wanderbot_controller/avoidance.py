import rclpy
from rclpy.node import Node
from geometry_msgs.msg import TwistStamped, Twist
from sensor_msgs.msg import LaserScan
import math
import numpy as np

RAD2DEG = 180.0 / math.pi

class LaserAvoid(Node):
    def __init__(self, name):
       
        super().__init__(name)
        
        # 声明并获取参数 
        self.declare_parameter("linear", 0.4)
        self.linear = self.get_parameter('linear').get_parameter_value().double_value # 直行速度
        self.declare_parameter("angular", 1.0)
        self.angular = self.get_parameter('angular').get_parameter_value().double_value # 转向角速度
        self.declare_parameter("LaserAngle", 45.0)
        self.LaserAngle = self.get_parameter('LaserAngle').get_parameter_value().double_value # 避障检测角度 (单侧) [cite: 77]
        self.declare_parameter("ResponseDist", 0.45)
        self.ResponseDist = self.get_parameter('ResponseDist').get_parameter_value().double_value # 避障响应距离 [cite: 79]

        # 订阅雷达数据话题 /scan 
        self.sub_laser = self.create_subscription(LaserScan, "/scan", self.registerScan, 1)
        # 发布小车速度话题 /cmd_vel 
        self.pub_vel = self.create_publisher(TwistStamped, '/cmd_vel', 1)
        
        self.get_logger().info("Laser Avoidance Node started")

    def exit_pro(self):
        # 停止小车 
        ts = TwistStamped() 
        ts.header.stamp = self.get_clock().now().to_msg()
        ts.twist.linear.x = 0.0
        ts.twist.angular.z = 0.0 
        self.pub_vel.publish(ts)
        self.get_logger().info("Stopping robot and exiting...")

    def registerScan(self, scan_data):
        if not isinstance(scan_data, LaserScan):
            return
        
        # 将距离数据转换为 numpy 数组 
        ranges = np.array(scan_data.ranges)
        
        
        # 计算雷达数据总点数
        data_len = len(ranges)
        # 计算角度增量
        angle_increment = scan_data.angle_increment 
        angle_rad = self.LaserAngle * math.pi / 180.0
        
        #接获取前方中央 N 个点
        center_index = int(data_len / 2)
        points_to_check = int(self.LaserAngle / (angle_increment * 180.0 / math.pi))
        
        # 提取前方中央 90 度
        check_width = int(90 / (angle_increment * 180.0 / math.pi))
        
        start_index = int(180 - self.LaserAngle)
        end_index = int(180 + self.LaserAngle)
        
        front_ranges = ranges[start_index:end_index]
        # 过滤掉无效值并找到区域内的最小距离
        min_dist = np.min(front_ranges[np.isfinite(front_ranges)])
        
  
        ts = TwistStamped()
        ts.header.stamp = self.get_clock().now().to_msg()
        
        if min_dist < self.ResponseDist:
            
            ts.twist.linear.x = 0.0 
            
            
            ts.twist.angular.z = self.angular 
            self.get_logger().info(f"Obstacle detected at {min_dist:.2f}m. Turning left.")
        else:
            
            ts.twist.linear.x = self.linear 
            ts.twist.angular.z = 0.0
            self.get_logger().info("Clear path. Moving forward.")
            
        # 发布速度
        self.pub_vel.publish(ts)


def main(args=None):
    rclpy.init(args=args)
    
    laser_avoid = LaserAvoid("laser_Avoidance")
    print("laser avoidance started")
    
    try:
        rclpy.spin(laser_avoid)
    except KeyboardInterrupt:
        pass
    finally:
        laser_avoid.exit_pro()
        laser_avoid.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()