import rclpy
from rclpy.node import Node
from pkg_interfaces.msg import MyMessage
import time

class VelocityPublisher(Node):
    def __init__(self):
        super().__init__('velocity_publisher')
        # 创建发布者，发布自定义速度消息
        self.publisher_ = self.create_publisher(MyMessage, 'robot_velocity', 10)
        
        # 创建定时器，每5秒发布一次速度信息
        timer_period = 5.0  # 5秒
        self.timer = self.create_timer(timer_period, self.timer_callback)
        self.count = 0
        
        self.get_logger().info('速度控制节点已启动，每5秒发布一次速度信息')

    def timer_callback(self):
        # 创建自定义消息实例
        msg = MyMessage()
        
        # 模拟不同的速度值（循环变化）
        if self.count % 3 == 0:
            msg.x_velocity = 1.0  # x方向速度 1.0 m/s
            msg.y_velocity = 0.5  # y方向速度 0.5 m/s
        elif self.count % 3 == 1:
            msg.x_velocity = 0.5  # x方向速度 0.5 m/s
            msg.y_velocity = 1.0  # y方向速度 1.0 m/s
        else:
            msg.x_velocity = 0.8  # x方向速度 0.8 m/s
            msg.y_velocity = 0.8  # y方向速度 0.8 m/s
        
        # 发布速度信息
        self.publisher_.publish(msg)
        self.get_logger().info('发布速度信息: x=%.2f m/s, y=%.2f m/s' % 
                              (msg.x_velocity, msg.y_velocity))
        self.count += 1

def main(args=None):
    rclpy.init(args=args)
    velocity_publisher = VelocityPublisher()
    
    try:
        rclpy.spin(velocity_publisher)
    except KeyboardInterrupt:
        print('\n速度控制节点已关闭')
    finally:
        velocity_publisher.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()