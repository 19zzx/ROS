import rclpy
from rclpy.node import Node
from pkg_interfaces.msg import MyMessage
import math

class DistanceCalculator(Node):
    def __init__(self):
        super().__init__('distance_calculator')
        # 创建订阅者，订阅速度信息
        self.subscription = self.create_subscription(
            MyMessage,
            'robot_velocity',  # 订阅的话题名称
            self.velocity_callback,
            10)
        
        # 初始化变量
        self.total_distance = 0.0  # 总移动距离
        self.message_count = 0      # 接收到的消息计数
        
        self.get_logger().info('距离计算节点已启动，等待速度信息...')

    def velocity_callback(self, msg):
        # 时间间隔为5秒（与发布间隔一致）
        time_interval = 5.0
        
        # 计算瞬时速度大小（向量模长）
        instantaneous_speed = math.sqrt(
            msg.x_velocity**2 + msg.y_velocity**2
        )
        
        # 计算这段时间内的移动距离
        distance_increment = instantaneous_speed * time_interval
        
        # 累加总距离
        self.total_distance += distance_increment
        self.message_count += 1
        
        # 输出计算结果到控制台
        self.get_logger().info(
            '第%d次计算 | 速度: x=%.2f m/s, y=%.2f m/s | '
            '瞬时速度: %.2f m/s | 本次移动: %.2f m | 总距离: %.2f m' % 
            (self.message_count, msg.x_velocity, msg.y_velocity,
             instantaneous_speed, distance_increment, self.total_distance)
        )

def main(args=None):
    rclpy.init(args=args)
    distance_calculator = DistanceCalculator()
    
    try:
        rclpy.spin(distance_calculator)
    except KeyboardInterrupt:
        print('\n距离计算节点已关闭')
    finally:
        distance_calculator.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()