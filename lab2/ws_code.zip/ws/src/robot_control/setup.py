from setuptools import find_packages, setup

package_name = 'robot_control'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='zzx',
    maintainer_email='zzx@todo.todo',
    description='Robot control package with velocity control and distance calculation',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
                        'velocity_publisher = robot_control.velocity_publisher:main',
            'distance_calculator = robot_control.distance_calculator:main',
        ],
    },
)
