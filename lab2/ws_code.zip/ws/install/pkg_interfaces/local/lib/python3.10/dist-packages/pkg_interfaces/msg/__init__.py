from pkg_interfaces.msg._my_message import MyMessage  # noqa: F401
