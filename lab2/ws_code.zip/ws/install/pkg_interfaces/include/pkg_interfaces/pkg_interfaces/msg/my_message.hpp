// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef PKG_INTERFACES__MSG__MY_MESSAGE_HPP_
#define PKG_INTERFACES__MSG__MY_MESSAGE_HPP_

#include "pkg_interfaces/msg/detail/my_message__struct.hpp"
#include "pkg_interfaces/msg/detail/my_message__builder.hpp"
#include "pkg_interfaces/msg/detail/my_message__traits.hpp"
#include "pkg_interfaces/msg/detail/my_message__type_support.hpp"

#endif  // PKG_INTERFACES__MSG__MY_MESSAGE_HPP_
