// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from pkg_interfaces:msg/MyMessage.idl
// generated code does not contain a copyright notice

#ifndef PKG_INTERFACES__MSG__DETAIL__MY_MESSAGE__TRAITS_HPP_
#define PKG_INTERFACES__MSG__DETAIL__MY_MESSAGE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "pkg_interfaces/msg/detail/my_message__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace pkg_interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const MyMessage & msg,
  std::ostream & out)
{
  out << "{";
  // member: x_velocity
  {
    out << "x_velocity: ";
    rosidl_generator_traits::value_to_yaml(msg.x_velocity, out);
    out << ", ";
  }

  // member: y_velocity
  {
    out << "y_velocity: ";
    rosidl_generator_traits::value_to_yaml(msg.y_velocity, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const MyMessage & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: x_velocity
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "x_velocity: ";
    rosidl_generator_traits::value_to_yaml(msg.x_velocity, out);
    out << "\n";
  }

  // member: y_velocity
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "y_velocity: ";
    rosidl_generator_traits::value_to_yaml(msg.y_velocity, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const MyMessage & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace pkg_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use pkg_interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const pkg_interfaces::msg::MyMessage & msg,
  std::ostream & out, size_t indentation = 0)
{
  pkg_interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use pkg_interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const pkg_interfaces::msg::MyMessage & msg)
{
  return pkg_interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<pkg_interfaces::msg::MyMessage>()
{
  return "pkg_interfaces::msg::MyMessage";
}

template<>
inline const char * name<pkg_interfaces::msg::MyMessage>()
{
  return "pkg_interfaces/msg/MyMessage";
}

template<>
struct has_fixed_size<pkg_interfaces::msg::MyMessage>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<pkg_interfaces::msg::MyMessage>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<pkg_interfaces::msg::MyMessage>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // PKG_INTERFACES__MSG__DETAIL__MY_MESSAGE__TRAITS_HPP_
