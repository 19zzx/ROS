// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from pkg_interfaces:msg/MyMessage.idl
// generated code does not contain a copyright notice

#ifndef PKG_INTERFACES__MSG__DETAIL__MY_MESSAGE__BUILDER_HPP_
#define PKG_INTERFACES__MSG__DETAIL__MY_MESSAGE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "pkg_interfaces/msg/detail/my_message__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace pkg_interfaces
{

namespace msg
{

namespace builder
{

class Init_MyMessage_y_velocity
{
public:
  explicit Init_MyMessage_y_velocity(::pkg_interfaces::msg::MyMessage & msg)
  : msg_(msg)
  {}
  ::pkg_interfaces::msg::MyMessage y_velocity(::pkg_interfaces::msg::MyMessage::_y_velocity_type arg)
  {
    msg_.y_velocity = std::move(arg);
    return std::move(msg_);
  }

private:
  ::pkg_interfaces::msg::MyMessage msg_;
};

class Init_MyMessage_x_velocity
{
public:
  Init_MyMessage_x_velocity()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MyMessage_y_velocity x_velocity(::pkg_interfaces::msg::MyMessage::_x_velocity_type arg)
  {
    msg_.x_velocity = std::move(arg);
    return Init_MyMessage_y_velocity(msg_);
  }

private:
  ::pkg_interfaces::msg::MyMessage msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::pkg_interfaces::msg::MyMessage>()
{
  return pkg_interfaces::msg::builder::Init_MyMessage_x_velocity();
}

}  // namespace pkg_interfaces

#endif  // PKG_INTERFACES__MSG__DETAIL__MY_MESSAGE__BUILDER_HPP_
