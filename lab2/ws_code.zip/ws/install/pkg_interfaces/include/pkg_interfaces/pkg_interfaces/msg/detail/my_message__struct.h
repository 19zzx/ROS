// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from pkg_interfaces:msg/MyMessage.idl
// generated code does not contain a copyright notice

#ifndef PKG_INTERFACES__MSG__DETAIL__MY_MESSAGE__STRUCT_H_
#define PKG_INTERFACES__MSG__DETAIL__MY_MESSAGE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/MyMessage in the package pkg_interfaces.
typedef struct pkg_interfaces__msg__MyMessage
{
  float x_velocity;
  float y_velocity;
} pkg_interfaces__msg__MyMessage;

// Struct for a sequence of pkg_interfaces__msg__MyMessage.
typedef struct pkg_interfaces__msg__MyMessage__Sequence
{
  pkg_interfaces__msg__MyMessage * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} pkg_interfaces__msg__MyMessage__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // PKG_INTERFACES__MSG__DETAIL__MY_MESSAGE__STRUCT_H_
