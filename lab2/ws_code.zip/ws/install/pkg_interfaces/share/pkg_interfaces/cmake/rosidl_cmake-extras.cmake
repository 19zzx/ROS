# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(pkg_interfaces_IDL_FILES "msg/MyMessage.idl")
set(pkg_interfaces_INTERFACE_FILES "msg/MyMessage.msg")
